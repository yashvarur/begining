//program to count number of bit set in a given number
#include"header.h"
int main()
{
	int a;
	printf("enter the number\n");
	scanf("%d",&a);
	fun(a);
return 0;
}
