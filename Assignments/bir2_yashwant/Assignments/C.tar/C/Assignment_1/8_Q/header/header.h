#include<stdio.h>
int fun(int n);
