#include"header.h"
void fun()
{	
	printf("size of int data type=%d\n",sizeof(int));	
        printf("size of float data type=%d\n",sizeof(float));
        printf("size of double data type=%d\n",sizeof(double));
        printf("size of char data type=%d\n",sizeof(char));
}
