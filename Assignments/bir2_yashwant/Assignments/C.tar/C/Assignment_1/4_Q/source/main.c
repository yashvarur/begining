// program to find size of all datatypes
#include"header.h"
int main()
{
	fun();
return 0;
}
