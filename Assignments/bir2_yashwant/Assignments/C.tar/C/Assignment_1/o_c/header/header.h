#include<stdio.h>
void fun(char a);
