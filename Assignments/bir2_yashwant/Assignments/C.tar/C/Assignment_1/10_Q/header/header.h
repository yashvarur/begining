#include<stdio.h>
void fun(int a[],int n);
