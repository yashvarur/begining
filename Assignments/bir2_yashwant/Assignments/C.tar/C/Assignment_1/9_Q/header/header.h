#include<stdio.h>
void fun();
