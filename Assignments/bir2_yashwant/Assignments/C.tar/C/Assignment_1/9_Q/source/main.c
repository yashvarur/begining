// program to print prime number between 1 to 100
#include "header.h"
int main()
{
	fun();
	
return 0;
}
