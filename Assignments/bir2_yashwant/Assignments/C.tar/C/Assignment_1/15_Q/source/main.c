// program to swap two number without using 3rd variable
#include"header.h"
int main()
{
        int a,b;
        printf("enter the two number\n");
        scanf("%d%d",&a,&b);
        fun(a,b);
    return 0;
}

