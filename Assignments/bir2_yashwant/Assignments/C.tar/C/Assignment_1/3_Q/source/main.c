// program find grade achieved by the student in exam
#include"header.h"
int main() 
{
   	int marks;//used to read the marks of the student
	printf("enter the student marks\n");
 	scanf("%d",&marks);
 	fun(marks);
return 0;
}
  	
