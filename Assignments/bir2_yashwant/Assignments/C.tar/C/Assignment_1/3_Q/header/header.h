#include<stdio.h>
void fun(int m);

