
int fun(int n)
{
        int i,sum;
        for(i=0;i<n;i++)
        sum+=i;		//add the number and store it in sum variable
        return sum;
}

