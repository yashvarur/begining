#include<stdio.h>
int fun(int a);

