#include"stdio.h"
void fun(int a)
{ 
   	if(a%2==0)
   	printf("number is even\n");
   	else
   	printf("number is odd\n");
}
