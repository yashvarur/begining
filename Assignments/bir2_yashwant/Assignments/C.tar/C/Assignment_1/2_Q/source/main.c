// program to check wheather a given number is even or odd
#include"header.h"
int main()
{
   	int a;
   	printf("enter the number\n ");
   	scanf("%d",&a);
	fun(a);
return 0;
} 

