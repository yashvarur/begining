// program to set or clear a bit in given number
#include"header.h"
int main()
{
    int a,b,num;
	printf("enter the number \n");
	scanf("%d",&num);
     
        a=num;
	b=num;
        fun(a,b);
     
 return 0;
}

