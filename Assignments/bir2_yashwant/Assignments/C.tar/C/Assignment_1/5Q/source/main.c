// program to check wheather given character is ovel or consonant
#include"header.h"
int main()
{
	char a; // read the character from keyboard
	printf("enter the character\n");
	scanf("%c",&a);
	fun(a);
return 0;
}
