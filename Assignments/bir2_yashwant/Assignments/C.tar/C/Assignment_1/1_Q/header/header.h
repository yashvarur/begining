
#include <stdio.h>
float area(float r); 

