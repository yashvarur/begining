// program to find area of circle
#include"header.h"
int main()
{
	float r;//used to read the radius of cirlce
    	printf("enter the radius of circle\n");
    	scanf("%f",&r);
   	printf("area of circle=%f",area(r));//function call
return 0;
}
   
