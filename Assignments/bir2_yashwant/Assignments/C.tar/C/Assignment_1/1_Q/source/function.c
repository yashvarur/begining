float area(float r)	//function to calculatr area of circle
{
	float a;
	a=3.142*r*r; //3.142*radius*radius
 return a;
}
