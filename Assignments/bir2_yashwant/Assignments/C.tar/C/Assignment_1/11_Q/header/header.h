#include<stdio.h>
int fun(int num);
