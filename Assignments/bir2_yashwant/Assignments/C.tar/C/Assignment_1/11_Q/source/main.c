// program to find factorial of a given number
#include"header.h"
int main()
{
	int num,b;
	printf("enter the number\n");
	scanf("%d",&num);
	b=fun(num);
	printf("%d",b);
return 0;
}

