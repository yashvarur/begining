// program to check wheather a given number is palondrome or not
#include"header.h"
int main()
{
	int a=0,n,b;
	printf("enter the number you want to check\n");
	scanf("%d",&a);
        n=a;
        b=fun(n);	//function call
        printf("origional number =%d\n",a);
	printf("reverse number =%d\n",b);
        if(a==b)	//checking the origional number with reversed number
	printf("number is palondrome\n");
	else
	printf("number is not a palondrome\n");
return 0;
}

