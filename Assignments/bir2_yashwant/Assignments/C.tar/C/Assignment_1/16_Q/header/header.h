#include<stdio.h>
void fun(char *p);
