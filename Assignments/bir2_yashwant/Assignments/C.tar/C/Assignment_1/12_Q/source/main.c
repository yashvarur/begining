// program to display number in binary format
#include"header.h"
int main()
{
	int num;
	printf("enter the number\n ");
	scanf("%d",&num);
	fun(num);
return 0;
}
