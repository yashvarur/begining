#include<stdio.h>
void fun(int num);
