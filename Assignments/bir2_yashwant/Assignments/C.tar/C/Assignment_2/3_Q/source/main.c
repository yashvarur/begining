/* program to reverse a binary number */
#include"header.h"
int main()
{
	unsigned int num, num1;
	printf("enter the number\n");
	num = int_read();

	printf("origional number\n");
	binary(num);
	printf("\n"); 

	num1 = reverse(num);
	printf("reversed number\n");
	binary(num1);
	return 0;
}

	
	
