/* program to print fibonacci series using recurssion */
#include"header.h"
int main()
{
        int num,i;
	printf("enter the range for fibonacci series\n");
	num = int_read();
	for(i = 1 ; i <= num ; i++)
	printf("%d\t",fib(i));
	return 0;
}
	
