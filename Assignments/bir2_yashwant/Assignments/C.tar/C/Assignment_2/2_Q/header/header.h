
#ifndef header 
#define header 1
#define SIZE 500
#include<limits.h>
#include<stdlib.h>
#include<stdio.h>
#include<string.h>

#define LEN 500
#define FREE(s) free(s);\
		s = NULL;
int int_read();
void binary(int n);
int bit_ts(int num, int pos);

#endif
