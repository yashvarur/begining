#include"header.h"
int bit_ts(int num, int pos) /*function to test and set the bit */ 
{

 	if (!( num & (1 << pos )))
		return (num | (1 << pos));
	printf ("bit is set\n");
	return num;
	
}
