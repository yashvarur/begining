/* program to count number of trailling zeros */
#include"header.h"
int main()
{
	int num, c;
	printf("enter the number\n");
	num = int_read();
	binary(num);
	c = t_count(num);
	printf("\nnumber of trailing zeros=%d\n",c);
	return 0;
}

	
