#include<stdio.h>
#include<stdlib.h>
typedef struct node
{
	int data;
	struct node *next;
}NODE;
NODE * push(NODE*p);
NODE * pop(NODE*p);
void display(NODE*p);

