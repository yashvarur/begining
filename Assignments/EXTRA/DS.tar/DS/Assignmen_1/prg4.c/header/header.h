#include<stdio.h>
#include<stdlib.h>
typedef struct node
{
	int data;
	struct node *next;
}NODE;
int l;
NODE* insert_rear(NODE *p);
void display(NODE *p);
NODE *insert_position(NODE *p);
NODE *insert_front(NODE *p);
NODE *insert_middle(NODE *p);
NODE *delete_rear(NODE * p);
NODE *delete_front(NODE *p);
NODE *delete_middle(NODE*p);
NODE *delete_position(NODE*p);


