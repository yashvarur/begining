#include"header.h"
void display()
{
	int i;
	if(q.front > q.rear)
		printf("no element to display\n");
	else {
	 	for(i=q.front ; i <= q.rear ; i++)
		printf("%d\t",q.a[i]);
	}
	printf("\n");
}	
