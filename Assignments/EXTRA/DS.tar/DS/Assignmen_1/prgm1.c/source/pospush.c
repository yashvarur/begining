#include"header.h"
void pushn(int pos,int ele)
{
	int i;
	if(pos > (MAX-1) )
		printf("you can't insert in this position\n");
	else {
		st.s[st.top + pos] = ele;
		for(i = 0 ; i < pos ; i++)
			st.top++;
	}	
}
