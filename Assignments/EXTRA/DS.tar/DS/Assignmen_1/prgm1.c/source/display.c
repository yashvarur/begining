#include"header.h"
void display()
{
	int i;
	for(i=st.top;i>=0;i--) {
		printf("%d\t",st.s[i]);
	}
}
