#include"header.h"
void pop()
{
	int ele;
	if(st.top == -1) {
		printf("stack underflow\n");
	}
	else {
		ele = st.s[st.top];
		st.s[st.top]^=st.s[st.top];
		st.top--;
		printf("poped elements is = %d\t",ele);


	}
}
		
