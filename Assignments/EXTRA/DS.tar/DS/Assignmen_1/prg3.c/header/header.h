#include<stdio.h>
#include<stdlib.h>
#define MAX 6

struct circular_queue
{
	int front;
	int rear;
	int s[MAX];
}cq;

void enque();
void deque();
void display();

